﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        pnlRight = New Panel()
        btnAboutUs = New Button()
        btnClothes = New Button()
        btnToys = New Button()
        btnShoes = New Button()
        btnAccessories = New Button()
        btnLogo = New Button()
        pnlTop = New Panel()
        btnMinimize = New Button()
        btnClose = New Button()
        btnMaximize = New Button()
        clothesPanel = New Panel()
        Panel4 = New Panel()
        Label4 = New Label()
        Button5 = New Button()
        Panel5 = New Panel()
        Label5 = New Label()
        Button6 = New Button()
        Panel6 = New Panel()
        Label6 = New Label()
        Button4 = New Button()
        Panel3 = New Panel()
        Button3 = New Button()
        Panel2 = New Panel()
        Label2 = New Label()
        Button2 = New Button()
        Panel1 = New Panel()
        Label1 = New Label()
        Button1 = New Button()
        toysPanel = New Panel()
        Panel8 = New Panel()
        Label7 = New Label()
        Button7 = New Button()
        Panel9 = New Panel()
        Label8 = New Label()
        Button8 = New Button()
        Panel10 = New Panel()
        Label9 = New Label()
        Button9 = New Button()
        Panel11 = New Panel()
        Label10 = New Label()
        Button10 = New Button()
        Panel12 = New Panel()
        Label11 = New Label()
        Button11 = New Button()
        Panel13 = New Panel()
        Label12 = New Label()
        Button12 = New Button()
        shoesPanel = New Panel()
        Panel14 = New Panel()
        Label13 = New Label()
        Button13 = New Button()
        Panel15 = New Panel()
        Label14 = New Label()
        Button14 = New Button()
        Panel16 = New Panel()
        Label15 = New Label()
        Button15 = New Button()
        Panel17 = New Panel()
        Label16 = New Label()
        Button16 = New Button()
        Panel19 = New Panel()
        Label18 = New Label()
        Button18 = New Button()
        accessoriesPanel = New Panel()
        Panel18 = New Panel()
        Label17 = New Label()
        Button17 = New Button()
        Panel20 = New Panel()
        Label19 = New Label()
        Button19 = New Button()
        Panel21 = New Panel()
        Label20 = New Label()
        Button20 = New Button()
        Panel23 = New Panel()
        Label22 = New Label()
        Button22 = New Button()
        Panel24 = New Panel()
        Label23 = New Label()
        Button23 = New Button()
        aboutusPanel = New Panel()
        TextBox7 = New TextBox()
        TextBox6 = New TextBox()
        TextBox5 = New TextBox()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label3 = New Label()
        pnlRight.SuspendLayout()
        pnlTop.SuspendLayout()
        clothesPanel.SuspendLayout()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        Panel3.SuspendLayout()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        toysPanel.SuspendLayout()
        Panel8.SuspendLayout()
        Panel9.SuspendLayout()
        Panel10.SuspendLayout()
        Panel11.SuspendLayout()
        Panel12.SuspendLayout()
        Panel13.SuspendLayout()
        shoesPanel.SuspendLayout()
        Panel14.SuspendLayout()
        Panel15.SuspendLayout()
        Panel16.SuspendLayout()
        Panel17.SuspendLayout()
        Panel19.SuspendLayout()
        accessoriesPanel.SuspendLayout()
        Panel18.SuspendLayout()
        Panel20.SuspendLayout()
        Panel21.SuspendLayout()
        Panel23.SuspendLayout()
        Panel24.SuspendLayout()
        aboutusPanel.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlRight
        ' 
        pnlRight.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        pnlRight.Controls.Add(btnAboutUs)
        pnlRight.Controls.Add(btnClothes)
        pnlRight.Controls.Add(btnToys)
        pnlRight.Controls.Add(btnShoes)
        pnlRight.Controls.Add(btnAccessories)
        pnlRight.Controls.Add(btnLogo)
        pnlRight.ForeColor = Color.White
        pnlRight.Location = New Point(765, 0)
        pnlRight.Name = "pnlRight"
        pnlRight.Size = New Size(195, 552)
        pnlRight.TabIndex = 0
        ' 
        ' btnAboutUs
        ' 
        btnAboutUs.FlatAppearance.BorderSize = 0
        btnAboutUs.FlatStyle = FlatStyle.Flat
        btnAboutUs.Font = New Font("Chiller", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAboutUs.ForeColor = Color.Black
        btnAboutUs.Location = New Point(0, 0)
        btnAboutUs.Name = "btnAboutUs"
        btnAboutUs.Size = New Size(195, 71)
        btnAboutUs.TabIndex = 5
        btnAboutUs.Text = "About Us"
        btnAboutUs.TextImageRelation = TextImageRelation.ImageAboveText
        btnAboutUs.UseVisualStyleBackColor = True
        ' 
        ' btnClothes
        ' 
        btnClothes.FlatAppearance.BorderSize = 0
        btnClothes.FlatStyle = FlatStyle.Flat
        btnClothes.Font = New Font("Chiller", 15.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        btnClothes.ForeColor = Color.Black
        btnClothes.Image = CType(resources.GetObject("btnClothes.Image"), Image)
        btnClothes.Location = New Point(0, 82)
        btnClothes.Name = "btnClothes"
        btnClothes.Size = New Size(192, 73)
        btnClothes.TabIndex = 4
        btnClothes.Text = "Clothes"
        btnClothes.TextImageRelation = TextImageRelation.ImageAboveText
        btnClothes.UseVisualStyleBackColor = True
        ' 
        ' btnToys
        ' 
        btnToys.FlatAppearance.BorderSize = 0
        btnToys.FlatStyle = FlatStyle.Flat
        btnToys.Font = New Font("Chiller", 15.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnToys.ForeColor = Color.Black
        btnToys.Image = CType(resources.GetObject("btnToys.Image"), Image)
        btnToys.Location = New Point(0, 170)
        btnToys.Name = "btnToys"
        btnToys.Size = New Size(192, 76)
        btnToys.TabIndex = 3
        btnToys.Text = "Toys"
        btnToys.TextImageRelation = TextImageRelation.ImageAboveText
        btnToys.UseVisualStyleBackColor = True
        ' 
        ' btnShoes
        ' 
        btnShoes.FlatAppearance.BorderSize = 0
        btnShoes.FlatStyle = FlatStyle.Flat
        btnShoes.Font = New Font("Chiller", 15.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnShoes.ForeColor = Color.Black
        btnShoes.Image = CType(resources.GetObject("btnShoes.Image"), Image)
        btnShoes.Location = New Point(0, 258)
        btnShoes.Name = "btnShoes"
        btnShoes.Size = New Size(192, 75)
        btnShoes.TabIndex = 2
        btnShoes.Text = "Shoes"
        btnShoes.TextImageRelation = TextImageRelation.ImageAboveText
        btnShoes.UseVisualStyleBackColor = True
        ' 
        ' btnAccessories
        ' 
        btnAccessories.FlatAppearance.BorderSize = 0
        btnAccessories.FlatStyle = FlatStyle.Flat
        btnAccessories.Font = New Font("Chiller", 15.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAccessories.ForeColor = Color.Black
        btnAccessories.Image = CType(resources.GetObject("btnAccessories.Image"), Image)
        btnAccessories.Location = New Point(0, 349)
        btnAccessories.Name = "btnAccessories"
        btnAccessories.Size = New Size(192, 71)
        btnAccessories.TabIndex = 1
        btnAccessories.Text = "Accessories"
        btnAccessories.TextImageRelation = TextImageRelation.ImageAboveText
        btnAccessories.UseVisualStyleBackColor = True
        ' 
        ' btnLogo
        ' 
        btnLogo.FlatAppearance.BorderSize = 0
        btnLogo.FlatStyle = FlatStyle.Flat
        btnLogo.Font = New Font("Chiller", 15.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnLogo.ForeColor = Color.Black
        btnLogo.Image = CType(resources.GetObject("btnLogo.Image"), Image)
        btnLogo.Location = New Point(46, 483)
        btnLogo.Name = "btnLogo"
        btnLogo.Size = New Size(103, 66)
        btnLogo.TabIndex = 0
        btnLogo.Text = " More Cats"
        btnLogo.TextAlign = ContentAlignment.TopCenter
        btnLogo.UseVisualStyleBackColor = True
        ' 
        ' pnlTop
        ' 
        pnlTop.BackColor = SystemColors.ActiveCaptionText
        pnlTop.Controls.Add(btnMinimize)
        pnlTop.Controls.Add(btnClose)
        pnlTop.Controls.Add(btnMaximize)
        pnlTop.Location = New Point(0, 0)
        pnlTop.Name = "pnlTop"
        pnlTop.Size = New Size(765, 45)
        pnlTop.TabIndex = 1
        ' 
        ' btnMinimize
        ' 
        btnMinimize.BackgroundImage = CType(resources.GetObject("btnMinimize.BackgroundImage"), Image)
        btnMinimize.BackgroundImageLayout = ImageLayout.Zoom
        btnMinimize.FlatAppearance.BorderSize = 0
        btnMinimize.FlatStyle = FlatStyle.Flat
        btnMinimize.Font = New Font("Chiller", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMinimize.ForeColor = Color.Black
        btnMinimize.Location = New Point(49, 8)
        btnMinimize.Name = "btnMinimize"
        btnMinimize.Size = New Size(19, 28)
        btnMinimize.TabIndex = 8
        btnMinimize.Text = " "
        btnMinimize.TextImageRelation = TextImageRelation.ImageAboveText
        btnMinimize.UseVisualStyleBackColor = True
        ' 
        ' btnClose
        ' 
        btnClose.BackgroundImage = CType(resources.GetObject("btnClose.BackgroundImage"), Image)
        btnClose.BackgroundImageLayout = ImageLayout.Zoom
        btnClose.FlatAppearance.BorderSize = 0
        btnClose.FlatStyle = FlatStyle.Flat
        btnClose.Font = New Font("Chiller", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClose.ForeColor = Color.Black
        btnClose.Location = New Point(16, 8)
        btnClose.Name = "btnClose"
        btnClose.Size = New Size(19, 28)
        btnClose.TabIndex = 7
        btnClose.Text = " "
        btnClose.TextImageRelation = TextImageRelation.ImageAboveText
        btnClose.UseVisualStyleBackColor = True
        ' 
        ' btnMaximize
        ' 
        btnMaximize.BackgroundImage = My.Resources.Resources.Cat
        btnMaximize.BackgroundImageLayout = ImageLayout.Zoom
        btnMaximize.FlatAppearance.BorderSize = 0
        btnMaximize.FlatStyle = FlatStyle.Flat
        btnMaximize.Font = New Font("Chiller", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMaximize.ForeColor = Color.Black
        btnMaximize.Location = New Point(79, 7)
        btnMaximize.Name = "btnMaximize"
        btnMaximize.Size = New Size(22, 28)
        btnMaximize.TabIndex = 6
        btnMaximize.Text = " "
        btnMaximize.TextImageRelation = TextImageRelation.ImageAboveText
        btnMaximize.UseVisualStyleBackColor = True
        ' 
        ' clothesPanel
        ' 
        clothesPanel.Controls.Add(Panel4)
        clothesPanel.Controls.Add(Panel5)
        clothesPanel.Controls.Add(Panel6)
        clothesPanel.Controls.Add(Panel3)
        clothesPanel.Controls.Add(Panel2)
        clothesPanel.Controls.Add(Panel1)
        clothesPanel.Location = New Point(0, 42)
        clothesPanel.Name = "clothesPanel"
        clothesPanel.Size = New Size(765, 508)
        clothesPanel.TabIndex = 2
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(Button5)
        Panel4.Location = New Point(537, 290)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(192, 186)
        Panel4.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(45, 11)
        Label4.Name = "Label4"
        Label4.Size = New Size(98, 21)
        Label4.TabIndex = 1
        Label4.Text = "Undergarments"
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), Image)
        Button5.BackgroundImageLayout = ImageLayout.Stretch
        Button5.FlatAppearance.BorderSize = 0
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Location = New Point(15, 35)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 136)
        Button5.TabIndex = 0
        Button5.Text = " "
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(Label5)
        Panel5.Controls.Add(Button6)
        Panel5.Location = New Point(286, 290)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(192, 186)
        Panel5.TabIndex = 4
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(65, 11)
        Label5.Name = "Label5"
        Label5.Size = New Size(56, 21)
        Label5.TabIndex = 1
        Label5.Text = "Pajamas"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), Image)
        Button6.BackgroundImageLayout = ImageLayout.Stretch
        Button6.FlatAppearance.BorderSize = 0
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Location = New Point(15, 35)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 136)
        Button6.TabIndex = 0
        Button6.Text = " "
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Panel6
        ' 
        Panel6.Controls.Add(Label6)
        Panel6.Controls.Add(Button4)
        Panel6.Location = New Point(34, 290)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(192, 186)
        Panel6.TabIndex = 3
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(74, 11)
        Label6.Name = "Label6"
        Label6.Size = New Size(38, 21)
        Label6.TabIndex = 1
        Label6.Text = "Tees"
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), Image)
        Button4.BackgroundImageLayout = ImageLayout.Stretch
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Location = New Point(15, 35)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 136)
        Button4.TabIndex = 0
        Button4.Text = " "
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Panel3
        ' 
        Panel3.Controls.Add(Label3)
        Panel3.Controls.Add(Button3)
        Panel3.Location = New Point(537, 32)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(192, 186)
        Panel3.TabIndex = 2
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), Image)
        Button3.BackgroundImageLayout = ImageLayout.Stretch
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Location = New Point(15, 35)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 136)
        Button3.TabIndex = 0
        Button3.Text = " "
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Button2)
        Panel2.Location = New Point(286, 32)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(192, 186)
        Panel2.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(65, 11)
        Label2.Name = "Label2"
        Label2.Size = New Size(56, 21)
        Label2.TabIndex = 1
        Label2.Text = "Hoodies"
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
        Button2.BackgroundImageLayout = ImageLayout.Stretch
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Location = New Point(15, 35)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 136)
        Button2.TabIndex = 0
        Button2.Text = " "
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(Button1)
        Panel1.Location = New Point(34, 32)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(192, 186)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(71, 11)
        Label1.Name = "Label1"
        Label1.Size = New Size(43, 21)
        Label1.TabIndex = 1
        Label1.Text = "Pants"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
        Button1.BackgroundImageLayout = ImageLayout.Stretch
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Location = New Point(15, 35)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 136)
        Button1.TabIndex = 0
        Button1.Text = " "
        Button1.UseVisualStyleBackColor = False
        ' 
        ' toysPanel
        ' 
        toysPanel.Controls.Add(Panel8)
        toysPanel.Controls.Add(Panel9)
        toysPanel.Controls.Add(Panel10)
        toysPanel.Controls.Add(Panel11)
        toysPanel.Controls.Add(Panel12)
        toysPanel.Controls.Add(Panel13)
        toysPanel.Location = New Point(0, 42)
        toysPanel.Name = "toysPanel"
        toysPanel.Size = New Size(765, 508)
        toysPanel.TabIndex = 3
        ' 
        ' Panel8
        ' 
        Panel8.Controls.Add(Label7)
        Panel8.Controls.Add(Button7)
        Panel8.Location = New Point(537, 290)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(192, 186)
        Panel8.TabIndex = 5
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(57, 11)
        Label7.Name = "Label7"
        Label7.Size = New Size(83, 21)
        Label7.TabIndex = 1
        Label7.Text = "Instruments"
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), Image)
        Button7.BackgroundImageLayout = ImageLayout.Stretch
        Button7.FlatAppearance.BorderColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button7.FlatAppearance.BorderSize = 0
        Button7.FlatAppearance.MouseDownBackColor = Color.White
        Button7.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Location = New Point(15, 35)
        Button7.Name = "Button7"
        Button7.Size = New Size(162, 136)
        Button7.TabIndex = 0
        Button7.Text = " "
        Button7.UseVisualStyleBackColor = False
        ' 
        ' Panel9
        ' 
        Panel9.Controls.Add(Label8)
        Panel9.Controls.Add(Button8)
        Panel9.Location = New Point(286, 290)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(192, 186)
        Panel9.TabIndex = 4
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(65, 11)
        Label8.Name = "Label8"
        Label8.Size = New Size(50, 21)
        Label8.TabIndex = 1
        Label8.Text = "Catnip"
        ' 
        ' Button8
        ' 
        Button8.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), Image)
        Button8.BackgroundImageLayout = ImageLayout.Stretch
        Button8.FlatAppearance.BorderSize = 0
        Button8.FlatStyle = FlatStyle.Flat
        Button8.Location = New Point(15, 35)
        Button8.Name = "Button8"
        Button8.Size = New Size(162, 136)
        Button8.TabIndex = 0
        Button8.Text = " "
        Button8.UseVisualStyleBackColor = False
        ' 
        ' Panel10
        ' 
        Panel10.Controls.Add(Label9)
        Panel10.Controls.Add(Button9)
        Panel10.Location = New Point(34, 290)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(192, 186)
        Panel10.TabIndex = 3
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(57, 11)
        Label9.Name = "Label9"
        Label9.Size = New Size(67, 21)
        Label9.TabIndex = 1
        Label9.Text = "Lightning"
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button9.BackgroundImage = CType(resources.GetObject("Button9.BackgroundImage"), Image)
        Button9.BackgroundImageLayout = ImageLayout.Stretch
        Button9.FlatAppearance.BorderSize = 0
        Button9.FlatStyle = FlatStyle.Flat
        Button9.Location = New Point(15, 35)
        Button9.Name = "Button9"
        Button9.Size = New Size(162, 136)
        Button9.TabIndex = 0
        Button9.Text = " "
        Button9.UseVisualStyleBackColor = False
        ' 
        ' Panel11
        ' 
        Panel11.Controls.Add(Label10)
        Panel11.Controls.Add(Button10)
        Panel11.Location = New Point(537, 32)
        Panel11.Name = "Panel11"
        Panel11.Size = New Size(192, 186)
        Panel11.TabIndex = 2
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(76, 11)
        Label10.Name = "Label10"
        Label10.Size = New Size(40, 21)
        Label10.TabIndex = 1
        Label10.Text = "Balls"
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button10.BackgroundImage = CType(resources.GetObject("Button10.BackgroundImage"), Image)
        Button10.BackgroundImageLayout = ImageLayout.Stretch
        Button10.FlatAppearance.BorderSize = 0
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Location = New Point(15, 35)
        Button10.Name = "Button10"
        Button10.Size = New Size(162, 136)
        Button10.TabIndex = 0
        Button10.Text = " "
        Button10.UseVisualStyleBackColor = False
        ' 
        ' Panel12
        ' 
        Panel12.Controls.Add(Label11)
        Panel12.Controls.Add(Button11)
        Panel12.Location = New Point(286, 32)
        Panel12.Name = "Panel12"
        Panel12.Size = New Size(192, 186)
        Panel12.TabIndex = 1
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(46, 11)
        Label11.Name = "Label11"
        Label11.Size = New Size(108, 21)
        Label11.TabIndex = 1
        Label11.Text = "Mechanical Toys"
        ' 
        ' Button11
        ' 
        Button11.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button11.BackgroundImage = CType(resources.GetObject("Button11.BackgroundImage"), Image)
        Button11.BackgroundImageLayout = ImageLayout.Stretch
        Button11.FlatAppearance.BorderSize = 0
        Button11.FlatStyle = FlatStyle.Flat
        Button11.Location = New Point(15, 35)
        Button11.Name = "Button11"
        Button11.Size = New Size(162, 136)
        Button11.TabIndex = 0
        Button11.Text = " "
        Button11.UseVisualStyleBackColor = False
        ' 
        ' Panel13
        ' 
        Panel13.Controls.Add(Label12)
        Panel13.Controls.Add(Button12)
        Panel13.Location = New Point(34, 32)
        Panel13.Name = "Panel13"
        Panel13.Size = New Size(192, 186)
        Panel13.TabIndex = 0
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(44, 11)
        Label12.Name = "Label12"
        Label12.Size = New Size(106, 21)
        Label12.TabIndex = 1
        Label12.Text = "Stuffed Animals"
        ' 
        ' Button12
        ' 
        Button12.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button12.BackgroundImage = CType(resources.GetObject("Button12.BackgroundImage"), Image)
        Button12.BackgroundImageLayout = ImageLayout.Stretch
        Button12.FlatAppearance.BorderSize = 0
        Button12.FlatStyle = FlatStyle.Flat
        Button12.Location = New Point(15, 35)
        Button12.Name = "Button12"
        Button12.Size = New Size(162, 136)
        Button12.TabIndex = 0
        Button12.Text = " "
        Button12.UseVisualStyleBackColor = False
        ' 
        ' shoesPanel
        ' 
        shoesPanel.Controls.Add(Panel14)
        shoesPanel.Controls.Add(Panel15)
        shoesPanel.Controls.Add(Panel16)
        shoesPanel.Controls.Add(Panel17)
        shoesPanel.Controls.Add(Panel19)
        shoesPanel.Location = New Point(0, 42)
        shoesPanel.Name = "shoesPanel"
        shoesPanel.Size = New Size(765, 508)
        shoesPanel.TabIndex = 4
        ' 
        ' Panel14
        ' 
        Panel14.Controls.Add(Label13)
        Panel14.Controls.Add(Button13)
        Panel14.Location = New Point(537, 290)
        Panel14.Name = "Panel14"
        Panel14.Size = New Size(192, 186)
        Panel14.TabIndex = 5
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(73, 11)
        Label13.Name = "Label13"
        Label13.Size = New Size(42, 21)
        Label13.TabIndex = 1
        Label13.Text = "Socks"
        ' 
        ' Button13
        ' 
        Button13.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button13.BackgroundImage = CType(resources.GetObject("Button13.BackgroundImage"), Image)
        Button13.BackgroundImageLayout = ImageLayout.Stretch
        Button13.FlatAppearance.BorderSize = 0
        Button13.FlatStyle = FlatStyle.Flat
        Button13.Location = New Point(15, 35)
        Button13.Name = "Button13"
        Button13.Size = New Size(162, 136)
        Button13.TabIndex = 0
        Button13.Text = " "
        Button13.UseVisualStyleBackColor = False
        ' 
        ' Panel15
        ' 
        Panel15.Controls.Add(Label14)
        Panel15.Controls.Add(Button14)
        Panel15.Location = New Point(286, 290)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(192, 186)
        Panel15.TabIndex = 4
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(73, 11)
        Label14.Name = "Label14"
        Label14.Size = New Size(46, 21)
        Label14.TabIndex = 1
        Label14.Text = "Boots"
        ' 
        ' Button14
        ' 
        Button14.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button14.BackgroundImage = CType(resources.GetObject("Button14.BackgroundImage"), Image)
        Button14.BackgroundImageLayout = ImageLayout.Stretch
        Button14.FlatAppearance.BorderSize = 0
        Button14.FlatStyle = FlatStyle.Flat
        Button14.Location = New Point(15, 35)
        Button14.Name = "Button14"
        Button14.Size = New Size(162, 136)
        Button14.TabIndex = 0
        Button14.Text = " "
        Button14.UseVisualStyleBackColor = False
        ' 
        ' Panel16
        ' 
        Panel16.Controls.Add(Label15)
        Panel16.Controls.Add(Button15)
        Panel16.Location = New Point(34, 290)
        Panel16.Name = "Panel16"
        Panel16.Size = New Size(192, 186)
        Panel16.TabIndex = 3
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(57, 11)
        Label15.Name = "Label15"
        Label15.Size = New Size(76, 21)
        Label15.TabIndex = 1
        Label15.Text = "High-Heels"
        ' 
        ' Button15
        ' 
        Button15.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button15.BackgroundImage = CType(resources.GetObject("Button15.BackgroundImage"), Image)
        Button15.BackgroundImageLayout = ImageLayout.Stretch
        Button15.FlatAppearance.BorderSize = 0
        Button15.FlatStyle = FlatStyle.Flat
        Button15.Location = New Point(15, 35)
        Button15.Name = "Button15"
        Button15.Size = New Size(162, 136)
        Button15.TabIndex = 0
        Button15.Text = " "
        Button15.UseVisualStyleBackColor = False
        ' 
        ' Panel17
        ' 
        Panel17.Controls.Add(Label16)
        Panel17.Controls.Add(Button16)
        Panel17.Location = New Point(445, 34)
        Panel17.Name = "Panel17"
        Panel17.Size = New Size(192, 186)
        Panel17.TabIndex = 2
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label16.Location = New Point(64, 11)
        Label16.Name = "Label16"
        Label16.Size = New Size(61, 21)
        Label16.TabIndex = 1
        Label16.Text = "Sneakers"
        ' 
        ' Button16
        ' 
        Button16.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button16.BackgroundImage = CType(resources.GetObject("Button16.BackgroundImage"), Image)
        Button16.BackgroundImageLayout = ImageLayout.Stretch
        Button16.FlatAppearance.BorderSize = 0
        Button16.FlatStyle = FlatStyle.Flat
        Button16.Location = New Point(15, 35)
        Button16.Name = "Button16"
        Button16.Size = New Size(162, 136)
        Button16.TabIndex = 0
        Button16.Text = " "
        Button16.UseVisualStyleBackColor = False
        ' 
        ' Panel19
        ' 
        Panel19.Controls.Add(Label18)
        Panel19.Controls.Add(Button18)
        Panel19.Location = New Point(123, 34)
        Panel19.Name = "Panel19"
        Panel19.Size = New Size(192, 186)
        Panel19.TabIndex = 0
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(66, 11)
        Label18.Name = "Label18"
        Label18.Size = New Size(57, 21)
        Label18.TabIndex = 1
        Label18.Text = "Slippers"
        ' 
        ' Button18
        ' 
        Button18.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button18.BackgroundImage = CType(resources.GetObject("Button18.BackgroundImage"), Image)
        Button18.BackgroundImageLayout = ImageLayout.Stretch
        Button18.FlatAppearance.BorderSize = 0
        Button18.FlatStyle = FlatStyle.Flat
        Button18.Location = New Point(15, 35)
        Button18.Name = "Button18"
        Button18.Size = New Size(162, 136)
        Button18.TabIndex = 0
        Button18.Text = " "
        Button18.UseVisualStyleBackColor = False
        ' 
        ' accessoriesPanel
        ' 
        accessoriesPanel.Controls.Add(Panel18)
        accessoriesPanel.Controls.Add(Panel20)
        accessoriesPanel.Controls.Add(Panel21)
        accessoriesPanel.Controls.Add(Panel23)
        accessoriesPanel.Controls.Add(Panel24)
        accessoriesPanel.Location = New Point(0, 42)
        accessoriesPanel.Name = "accessoriesPanel"
        accessoriesPanel.Size = New Size(765, 508)
        accessoriesPanel.TabIndex = 5
        ' 
        ' Panel18
        ' 
        Panel18.Controls.Add(Label17)
        Panel18.Controls.Add(Button17)
        Panel18.Location = New Point(537, 290)
        Panel18.Name = "Panel18"
        Panel18.Size = New Size(192, 186)
        Panel18.TabIndex = 5
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label17.Location = New Point(74, 11)
        Label17.Name = "Label17"
        Label17.Size = New Size(52, 21)
        Label17.TabIndex = 1
        Label17.Text = "Collars"
        ' 
        ' Button17
        ' 
        Button17.BackColor = Color.White
        Button17.BackgroundImage = CType(resources.GetObject("Button17.BackgroundImage"), Image)
        Button17.BackgroundImageLayout = ImageLayout.Stretch
        Button17.FlatAppearance.BorderColor = Color.White
        Button17.FlatStyle = FlatStyle.Flat
        Button17.Location = New Point(15, 35)
        Button17.Name = "Button17"
        Button17.Size = New Size(162, 136)
        Button17.TabIndex = 0
        Button17.Text = " "
        Button17.UseVisualStyleBackColor = False
        ' 
        ' Panel20
        ' 
        Panel20.Controls.Add(Label19)
        Panel20.Controls.Add(Button19)
        Panel20.Location = New Point(286, 290)
        Panel20.Name = "Panel20"
        Panel20.Size = New Size(192, 186)
        Panel20.TabIndex = 4
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label19.Location = New Point(65, 11)
        Label19.Name = "Label19"
        Label19.Size = New Size(55, 21)
        Label19.TabIndex = 1
        Label19.Text = "Jewelry"
        ' 
        ' Button19
        ' 
        Button19.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button19.BackgroundImage = CType(resources.GetObject("Button19.BackgroundImage"), Image)
        Button19.BackgroundImageLayout = ImageLayout.Stretch
        Button19.FlatAppearance.BorderSize = 0
        Button19.FlatStyle = FlatStyle.Flat
        Button19.Location = New Point(15, 35)
        Button19.Name = "Button19"
        Button19.Size = New Size(162, 136)
        Button19.TabIndex = 0
        Button19.Text = " "
        Button19.UseVisualStyleBackColor = False
        ' 
        ' Panel21
        ' 
        Panel21.Controls.Add(Label20)
        Panel21.Controls.Add(Button20)
        Panel21.Location = New Point(34, 290)
        Panel21.Name = "Panel21"
        Panel21.Size = New Size(192, 186)
        Panel21.TabIndex = 3
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label20.Location = New Point(71, 10)
        Label20.Name = "Label20"
        Label20.Size = New Size(53, 21)
        Label20.TabIndex = 1
        Label20.Text = "Scarves"
        ' 
        ' Button20
        ' 
        Button20.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button20.BackgroundImage = CType(resources.GetObject("Button20.BackgroundImage"), Image)
        Button20.BackgroundImageLayout = ImageLayout.Stretch
        Button20.FlatAppearance.BorderSize = 0
        Button20.FlatStyle = FlatStyle.Flat
        Button20.Location = New Point(15, 35)
        Button20.Name = "Button20"
        Button20.Size = New Size(162, 136)
        Button20.TabIndex = 0
        Button20.Text = " "
        Button20.UseVisualStyleBackColor = False
        ' 
        ' Panel23
        ' 
        Panel23.Controls.Add(Label22)
        Panel23.Controls.Add(Button22)
        Panel23.Location = New Point(484, 33)
        Panel23.Name = "Panel23"
        Panel23.Size = New Size(192, 186)
        Panel23.TabIndex = 1
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label22.Location = New Point(79, 11)
        Label22.Name = "Label22"
        Label22.Size = New Size(36, 21)
        Label22.TabIndex = 1
        Label22.Text = "Hats"
        ' 
        ' Button22
        ' 
        Button22.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button22.BackgroundImage = CType(resources.GetObject("Button22.BackgroundImage"), Image)
        Button22.BackgroundImageLayout = ImageLayout.Stretch
        Button22.FlatAppearance.BorderSize = 0
        Button22.FlatStyle = FlatStyle.Flat
        Button22.Location = New Point(15, 35)
        Button22.Name = "Button22"
        Button22.Size = New Size(162, 136)
        Button22.TabIndex = 0
        Button22.Text = " "
        Button22.UseVisualStyleBackColor = False
        ' 
        ' Panel24
        ' 
        Panel24.Controls.Add(Label23)
        Panel24.Controls.Add(Button23)
        Panel24.Location = New Point(92, 33)
        Panel24.Name = "Panel24"
        Panel24.Size = New Size(192, 186)
        Panel24.TabIndex = 0
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label23.Location = New Point(61, 11)
        Label23.Name = "Label23"
        Label23.Size = New Size(73, 21)
        Label23.TabIndex = 1
        Label23.Text = "Sunglasses"
        ' 
        ' Button23
        ' 
        Button23.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button23.BackgroundImage = CType(resources.GetObject("Button23.BackgroundImage"), Image)
        Button23.BackgroundImageLayout = ImageLayout.Stretch
        Button23.FlatAppearance.BorderSize = 0
        Button23.FlatStyle = FlatStyle.Flat
        Button23.Location = New Point(15, 35)
        Button23.Name = "Button23"
        Button23.Size = New Size(162, 136)
        Button23.TabIndex = 0
        Button23.Text = " "
        Button23.UseVisualStyleBackColor = False
        ' 
        ' aboutusPanel
        ' 
        aboutusPanel.Controls.Add(TextBox7)
        aboutusPanel.Controls.Add(TextBox6)
        aboutusPanel.Controls.Add(TextBox5)
        aboutusPanel.Controls.Add(TextBox4)
        aboutusPanel.Controls.Add(TextBox3)
        aboutusPanel.Controls.Add(TextBox2)
        aboutusPanel.Controls.Add(TextBox1)
        aboutusPanel.Location = New Point(0, 42)
        aboutusPanel.Name = "aboutusPanel"
        aboutusPanel.Size = New Size(765, 508)
        aboutusPanel.TabIndex = 6
        ' 
        ' TextBox7
        ' 
        TextBox7.BackColor = Color.White
        TextBox7.BorderStyle = BorderStyle.None
        TextBox7.Font = New Font("Chiller", 18.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox7.Location = New Point(321, 366)
        TextBox7.Multiline = True
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(106, 26)
        TextBox7.TabIndex = 6
        TextBox7.Text = "Special Thanks"
        ' 
        ' TextBox6
        ' 
        TextBox6.BackColor = Color.White
        TextBox6.BorderStyle = BorderStyle.None
        TextBox6.Font = New Font("Chiller", 18.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox6.Location = New Point(321, 124)
        TextBox6.Multiline = True
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(100, 26)
        TextBox6.TabIndex = 5
        TextBox6.Text = "Our Story"
        TextBox6.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox5
        ' 
        TextBox5.BorderStyle = BorderStyle.None
        TextBox5.Font = New Font("Papyrus", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox5.Location = New Point(62, 397)
        TextBox5.Multiline = True
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(652, 64)
        TextBox5.TabIndex = 4
        TextBox5.Text = resources.GetString("TextBox5.Text")
        TextBox5.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox4
        ' 
        TextBox4.BorderStyle = BorderStyle.None
        TextBox4.Font = New Font("Papyrus", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox4.Location = New Point(62, 271)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(652, 84)
        TextBox4.TabIndex = 3
        TextBox4.Text = resources.GetString("TextBox4.Text")
        TextBox4.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox3
        ' 
        TextBox3.BorderStyle = BorderStyle.None
        TextBox3.Font = New Font("Papyrus", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox3.Location = New Point(62, 156)
        TextBox3.Multiline = True
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(652, 105)
        TextBox3.TabIndex = 2
        TextBox3.Text = resources.GetString("TextBox3.Text")
        TextBox3.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox2
        ' 
        TextBox2.BorderStyle = BorderStyle.None
        TextBox2.Font = New Font("Chiller", 18.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox2.Location = New Point(321, 7)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(100, 28)
        TextBox2.TabIndex = 1
        TextBox2.Text = "About Us"
        TextBox2.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox1
        ' 
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.Font = New Font("Papyrus", 9.0F)
        TextBox1.Location = New Point(62, 48)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(643, 65)
        TextBox1.TabIndex = 0
        TextBox1.Text = resources.GetString("TextBox1.Text")
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Chiller", 13.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(60, 10)
        Label3.Name = "Label3"
        Label3.Size = New Size(72, 21)
        Label3.TabIndex = 2
        Label3.Text = "Cardigains"
        ' 
        ' Form1
        ' 
        AutoScaleMode = AutoScaleMode.None
        BackColor = SystemColors.Control
        ClientSize = New Size(960, 548)
        Controls.Add(aboutusPanel)
        Controls.Add(accessoriesPanel)
        Controls.Add(shoesPanel)
        Controls.Add(toysPanel)
        Controls.Add(clothesPanel)
        Controls.Add(pnlTop)
        Controls.Add(pnlRight)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form1"
        Text = "Form1"
        pnlRight.ResumeLayout(False)
        pnlTop.ResumeLayout(False)
        clothesPanel.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        toysPanel.ResumeLayout(False)
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        Panel10.ResumeLayout(False)
        Panel10.PerformLayout()
        Panel11.ResumeLayout(False)
        Panel11.PerformLayout()
        Panel12.ResumeLayout(False)
        Panel12.PerformLayout()
        Panel13.ResumeLayout(False)
        Panel13.PerformLayout()
        shoesPanel.ResumeLayout(False)
        Panel14.ResumeLayout(False)
        Panel14.PerformLayout()
        Panel15.ResumeLayout(False)
        Panel15.PerformLayout()
        Panel16.ResumeLayout(False)
        Panel16.PerformLayout()
        Panel17.ResumeLayout(False)
        Panel17.PerformLayout()
        Panel19.ResumeLayout(False)
        Panel19.PerformLayout()
        accessoriesPanel.ResumeLayout(False)
        Panel18.ResumeLayout(False)
        Panel18.PerformLayout()
        Panel20.ResumeLayout(False)
        Panel20.PerformLayout()
        Panel21.ResumeLayout(False)
        Panel21.PerformLayout()
        Panel23.ResumeLayout(False)
        Panel23.PerformLayout()
        Panel24.ResumeLayout(False)
        Panel24.PerformLayout()
        aboutusPanel.ResumeLayout(False)
        aboutusPanel.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents pnlRight As Panel
    Friend WithEvents btnLogo As Button
    Friend WithEvents pnlTop As Panel
    Friend WithEvents btnAccessories As Button
    Friend WithEvents btnShoes As Button
    Friend WithEvents btnToys As Button
    Friend WithEvents btnClothes As Button
    Friend WithEvents clothesPanel As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents toysPanel As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents Button10 As Button
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Button11 As Button
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Button12 As Button
    Friend WithEvents shoesPanel As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Button13 As Button
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Button14 As Button
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Button15 As Button
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Label16 As Label
    Friend WithEvents Button16 As Button
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Label18 As Label
    Friend WithEvents Button18 As Button
    Friend WithEvents accessoriesPanel As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents Button17 As Button
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Button19 As Button
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents Button20 As Button
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Label22 As Label
    Friend WithEvents Button22 As Button
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Button23 As Button
    Friend WithEvents btnAboutUs As Button
    Friend WithEvents aboutusPanel As Panel
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents btnMaximize As Button
    Friend WithEvents btnMinimize As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents Label3 As Label

End Class
