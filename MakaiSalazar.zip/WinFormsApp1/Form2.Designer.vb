﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Panel1 = New Panel()
        btnAboutUs = New Button()
        btnMinimize = New Button()
        btnClose = New Button()
        btnMaximize = New Button()
        Panel2 = New Panel()
        Label2 = New Label()
        Button2 = New Button()
        Panel3 = New Panel()
        Label1 = New Label()
        Button1 = New Button()
        Panel4 = New Panel()
        Label3 = New Label()
        Button3 = New Button()
        Panel5 = New Panel()
        Label4 = New Label()
        Button4 = New Button()
        Panel6 = New Panel()
        Label5 = New Label()
        Button5 = New Button()
        Panel7 = New Panel()
        Label6 = New Label()
        Button6 = New Button()
        Panel8 = New Panel()
        Label7 = New Label()
        Button7 = New Button()
        Panel9 = New Panel()
        Label8 = New Label()
        Button8 = New Button()
        Button9 = New Button()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        Panel7.SuspendLayout()
        Panel8.SuspendLayout()
        Panel9.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ActiveCaptionText
        Panel1.Controls.Add(btnAboutUs)
        Panel1.Controls.Add(btnMinimize)
        Panel1.Controls.Add(btnClose)
        Panel1.Controls.Add(btnMaximize)
        Panel1.Location = New Point(-4, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(957, 61)
        Panel1.TabIndex = 0
        ' 
        ' btnAboutUs
        ' 
        btnAboutUs.BackColor = Color.Transparent
        btnAboutUs.Cursor = Cursors.IBeam
        btnAboutUs.FlatAppearance.BorderSize = 0
        btnAboutUs.FlatStyle = FlatStyle.Flat
        btnAboutUs.Font = New Font("Chiller", 22F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAboutUs.ForeColor = Color.WhiteSmoke
        btnAboutUs.Location = New Point(408, 3)
        btnAboutUs.Name = "btnAboutUs"
        btnAboutUs.Size = New Size(157, 54)
        btnAboutUs.TabIndex = 6
        btnAboutUs.Text = "AdoptACat"
        btnAboutUs.TextImageRelation = TextImageRelation.ImageAboveText
        btnAboutUs.UseVisualStyleBackColor = False
        ' 
        ' btnMinimize
        ' 
        btnMinimize.BackgroundImage = CType(resources.GetObject("btnMinimize.BackgroundImage"), Image)
        btnMinimize.BackgroundImageLayout = ImageLayout.Zoom
        btnMinimize.FlatAppearance.BorderSize = 0
        btnMinimize.FlatStyle = FlatStyle.Flat
        btnMinimize.Font = New Font("Chiller", 20F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMinimize.ForeColor = Color.Black
        btnMinimize.Location = New Point(61, 16)
        btnMinimize.Name = "btnMinimize"
        btnMinimize.Size = New Size(19, 28)
        btnMinimize.TabIndex = 11
        btnMinimize.Text = " "
        btnMinimize.TextImageRelation = TextImageRelation.ImageAboveText
        btnMinimize.UseVisualStyleBackColor = True
        ' 
        ' btnClose
        ' 
        btnClose.BackgroundImage = CType(resources.GetObject("btnClose.BackgroundImage"), Image)
        btnClose.BackgroundImageLayout = ImageLayout.Zoom
        btnClose.FlatAppearance.BorderSize = 0
        btnClose.FlatStyle = FlatStyle.Flat
        btnClose.Font = New Font("Chiller", 20F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClose.ForeColor = Color.Black
        btnClose.Location = New Point(25, 16)
        btnClose.Name = "btnClose"
        btnClose.Size = New Size(19, 28)
        btnClose.TabIndex = 10
        btnClose.Text = " "
        btnClose.TextImageRelation = TextImageRelation.ImageAboveText
        btnClose.UseVisualStyleBackColor = True
        ' 
        ' btnMaximize
        ' 
        btnMaximize.BackgroundImage = My.Resources.Resources.Cat
        btnMaximize.BackgroundImageLayout = ImageLayout.Zoom
        btnMaximize.FlatAppearance.BorderSize = 0
        btnMaximize.FlatStyle = FlatStyle.Flat
        btnMaximize.Font = New Font("Chiller", 20F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMaximize.ForeColor = Color.Black
        btnMaximize.Location = New Point(94, 15)
        btnMaximize.Name = "btnMaximize"
        btnMaximize.Size = New Size(22, 28)
        btnMaximize.TabIndex = 9
        btnMaximize.Text = " "
        btnMaximize.TextImageRelation = TextImageRelation.ImageAboveText
        btnMaximize.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Button2)
        Panel2.Location = New Point(21, 103)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(192, 186)
        Panel2.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(69, 11)
        Label2.Name = "Label2"
        Label2.Size = New Size(45, 21)
        Label2.TabIndex = 1
        Label2.Text = "Beelz"
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
        Button2.BackgroundImageLayout = ImageLayout.Stretch
        Button2.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button2.FlatAppearance.BorderSize = 2
        Button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Location = New Point(15, 35)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 136)
        Button2.TabIndex = 0
        Button2.Text = " "
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Panel3
        ' 
        Panel3.Controls.Add(Label1)
        Panel3.Controls.Add(Button1)
        Panel3.Location = New Point(261, 103)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(192, 186)
        Panel3.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(79, 11)
        Label1.Name = "Label1"
        Label1.Size = New Size(32, 21)
        Label1.TabIndex = 1
        Label1.Text = "Hex"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
        Button1.BackgroundImageLayout = ImageLayout.Stretch
        Button1.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button1.FlatAppearance.BorderSize = 2
        Button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Location = New Point(15, 35)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 136)
        Button1.TabIndex = 0
        Button1.Text = " "
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(Label3)
        Panel4.Controls.Add(Button3)
        Panel4.Location = New Point(499, 103)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(192, 186)
        Panel4.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(80, 11)
        Label3.Name = "Label3"
        Label3.Size = New Size(36, 21)
        Label3.TabIndex = 1
        Label3.Text = "Void"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), Image)
        Button3.BackgroundImageLayout = ImageLayout.Stretch
        Button3.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button3.FlatAppearance.BorderSize = 2
        Button3.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Location = New Point(15, 35)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 136)
        Button3.TabIndex = 0
        Button3.Text = " "
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(Label4)
        Panel5.Controls.Add(Button4)
        Panel5.Location = New Point(737, 103)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(192, 186)
        Panel5.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(83, 11)
        Label4.Name = "Label4"
        Label4.Size = New Size(36, 21)
        Label4.TabIndex = 1
        Label4.Text = "Ursa"
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), Image)
        Button4.BackgroundImageLayout = ImageLayout.Stretch
        Button4.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button4.FlatAppearance.BorderSize = 2
        Button4.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Location = New Point(15, 35)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 136)
        Button4.TabIndex = 0
        Button4.Text = " "
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Panel6
        ' 
        Panel6.Controls.Add(Label5)
        Panel6.Controls.Add(Button5)
        Panel6.Location = New Point(21, 336)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(192, 186)
        Panel6.TabIndex = 3
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(70, 11)
        Label5.Name = "Label5"
        Label5.Size = New Size(44, 21)
        Label5.TabIndex = 1
        Label5.Text = "Stella"
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), Image)
        Button5.BackgroundImageLayout = ImageLayout.Stretch
        Button5.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button5.FlatAppearance.BorderSize = 2
        Button5.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Location = New Point(15, 35)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 136)
        Button5.TabIndex = 0
        Button5.Text = " "
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Panel7
        ' 
        Panel7.Controls.Add(Label6)
        Panel7.Controls.Add(Button6)
        Panel7.Location = New Point(261, 336)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(192, 186)
        Panel7.TabIndex = 4
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(65, 11)
        Label6.Name = "Label6"
        Label6.Size = New Size(60, 21)
        Label6.TabIndex = 1
        Label6.Text = "Anomaly"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), Image)
        Button6.BackgroundImageLayout = ImageLayout.Stretch
        Button6.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button6.FlatAppearance.BorderSize = 2
        Button6.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button6.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Location = New Point(15, 35)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 136)
        Button6.TabIndex = 0
        Button6.Text = " "
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Panel8
        ' 
        Panel8.Controls.Add(Label7)
        Panel8.Controls.Add(Button7)
        Panel8.Location = New Point(499, 336)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(192, 186)
        Panel8.TabIndex = 5
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(73, 11)
        Label7.Name = "Label7"
        Label7.Size = New Size(52, 21)
        Label7.TabIndex = 1
        Label7.Text = "Lucifer"
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), Image)
        Button7.BackgroundImageLayout = ImageLayout.Stretch
        Button7.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button7.FlatAppearance.BorderSize = 2
        Button7.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button7.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Location = New Point(15, 35)
        Button7.Name = "Button7"
        Button7.Size = New Size(162, 136)
        Button7.TabIndex = 0
        Button7.Text = " "
        Button7.UseVisualStyleBackColor = False
        ' 
        ' Panel9
        ' 
        Panel9.Controls.Add(Label8)
        Panel9.Controls.Add(Button8)
        Panel9.Location = New Point(737, 336)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(192, 186)
        Panel9.TabIndex = 6
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(82, 11)
        Label8.Name = "Label8"
        Label8.Size = New Size(43, 21)
        Label8.TabIndex = 1
        Label8.Text = "Salem"
        ' 
        ' Button8
        ' 
        Button8.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), Image)
        Button8.BackgroundImageLayout = ImageLayout.Stretch
        Button8.FlatAppearance.BorderColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Button8.FlatAppearance.BorderSize = 2
        Button8.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button8.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button8.FlatStyle = FlatStyle.Flat
        Button8.Location = New Point(15, 35)
        Button8.Name = "Button8"
        Button8.Size = New Size(162, 136)
        Button8.TabIndex = 0
        Button8.Text = " "
        Button8.UseVisualStyleBackColor = False
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.Transparent
        Button9.Cursor = Cursors.IBeam
        Button9.FlatAppearance.BorderSize = 0
        Button9.FlatStyle = FlatStyle.Flat
        Button9.Font = New Font("Chiller", 13F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button9.ForeColor = Color.Black
        Button9.Location = New Point(292, 556)
        Button9.Name = "Button9"
        Button9.Size = New Size(370, 29)
        Button9.TabIndex = 12
        Button9.Text = "Returns and refunds not accepted"
        Button9.TextImageRelation = TextImageRelation.ImageAboveText
        Button9.UseVisualStyleBackColor = False
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Menu
        ClientSize = New Size(950, 581)
        Controls.Add(Button9)
        Controls.Add(Panel9)
        Controls.Add(Panel8)
        Controls.Add(Panel7)
        Controls.Add(Panel6)
        Controls.Add(Panel5)
        Controls.Add(Panel4)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form2"
        Text = "Form2"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnMinimize As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnMaximize As Button
    Friend WithEvents btnAboutUs As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
End Class
